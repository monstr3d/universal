﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ConsoleAppClever
{
    /// <summary>
    /// Many reads and the single write
    /// </summary>
    public  static class ManyReadSingleWriteServer
    {
        /// <summary>
        /// count
        /// </summary>
        static int count = 0;

        /// <summary>
        /// Locker
        /// </summary>
        static ReaderWriterLockSlim locker = new ReaderWriterLockSlim();

        /// <summary>
        /// Event
        /// </summary>
        static ManualResetEvent ev = new ManualResetEvent(false);

        /// <summary>
        /// Adds to count
        /// </summary>
        /// <param name="summand">Summand</param>
        static public void AddToCount(int summand)
        {
            if (!locker.IsWriteLockHeld)
            {
                ev.Reset();
            }
            locker.EnterWriteLock();
            try
            {
                count += summand;
            }
            finally
            {
                locker.ExitWriteLock();
                if (!locker.IsWriteLockHeld)
                {
                    ev.Set();
                }
            }
        }

        /// <summary>
        /// Gets conunt
        /// </summary>
        /// <returns></returns>
        static public int GetCount()
        {
            if (locker.IsWriteLockHeld)
            {
                ev.WaitOne();
            }
            return count;
        }

    }
}
