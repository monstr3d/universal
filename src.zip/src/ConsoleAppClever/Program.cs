﻿using System;
using System.Threading;

namespace ConsoleAppClever
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            EventHandler handler = (object sender, EventArgs arg) =>
            {
                Thread.Sleep(500);

             };

            var async = new AsyncCaller(handler);
            var completeOK = async.Invoke(null, null, 500);
            Console.WriteLine("Complete OK = " + completeOK);

            handler = (object sender, EventArgs arg) =>
            {
                Thread.Sleep(100);

            };

            async = new AsyncCaller(handler);
            completeOK = async.Invoke(null, null, 500);
            Console.WriteLine("Complete OK = " + completeOK);

        }
    }
}
