﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ConsoleAppClever
{
    /// <summary>
    /// Async caller
    /// </summary>
    public class AsyncCaller 
    {
        /// <summary>
        /// Event handler
        /// </summary>
        EventHandler handler;

        /// <summary>
        /// Event
        /// </summary>
        ManualResetEvent ev = new ManualResetEvent(false);

        /// <summary>
        /// The return value
        /// </summary>
        bool completed = false;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="handler">Event handler</param>
        public AsyncCaller(EventHandler handler)
        {
            this.handler = handler;
        }

        /// <summary>
        /// Invokes call
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="args">Arguments</param>
        /// <param name="timeout">Timeout</param>
        /// <returns>True id operation is completed</returns>
        public bool Invoke(object sender, EventArgs args, int timeout)
        {
            ev.Reset();
            handler.BeginInvoke(sender, args, Callback, null);
            ev.WaitOne(timeout);
            return completed;
        }

        void Callback(IAsyncResult result)
        {
            result.AsyncWaitHandle.WaitOne();
            handler.EndInvoke(result);
            completed = true;
            ev.Set();
        }

    }
}
