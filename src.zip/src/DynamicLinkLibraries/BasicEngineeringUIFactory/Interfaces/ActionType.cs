﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BasicEngineering.UI.Factory.Interfaces
{
    /// <summary>
    /// Type of action
    /// </summary>
    public enum ActionType
    {
        Calclulation,
        Animation, 
        Realtime
    }
}
