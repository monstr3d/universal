#ifndef COMMON_H
#define COMMON_H

#include <GL/gl.h>
#include <GL/glu.h>

#endif;