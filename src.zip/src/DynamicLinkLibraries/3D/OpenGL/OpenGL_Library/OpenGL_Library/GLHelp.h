#if !defined(GLHelpH)
#define GLHelpH
#include <windows.h>

BOOL bSetupPixelFormat(HDC hdc, int mode);

#endif