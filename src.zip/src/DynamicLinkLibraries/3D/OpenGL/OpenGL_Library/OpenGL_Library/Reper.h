#pragma once

class Reper
{
public:
	Reper(void);
	void SetLength(double length);
	void Draw();
public:
	~Reper(void);

private:
	double length;

};
