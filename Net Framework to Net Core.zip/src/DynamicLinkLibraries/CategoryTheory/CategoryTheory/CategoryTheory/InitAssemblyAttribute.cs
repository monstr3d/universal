﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CategoryTheory
{
    /// <summary>
    /// Inits assembly
    /// </summary>
    public class InitAssemblyAttribute : Attribute
    {

    }
}
