using System;
using System.Collections.Generic;
using System.Text;

namespace CategoryTheory
{
    /// <summary>
    /// Object with properties
    /// </summary>
    public interface IProperties
    {
        /// <summary>
        /// Proerties
        /// </summary>
        object Properties
        {
            get;
            set;
        }
    }
}
