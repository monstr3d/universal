using System;
using System.Collections.Generic;
using System.Text;

namespace CategoryTheory
{
    /// <summary>
    /// The math category
    /// </summary>
    public interface ICategory : IAdvancedCategoryObject
    {
    }
}
