using System;
using System.Collections.Generic;
using System.Text;

namespace CategoryTheory
{
    /// <summary>
    /// The object of a math category
    /// </summary>
    public interface ICategoryObject : IAssociatedObject
    {

    }
}
