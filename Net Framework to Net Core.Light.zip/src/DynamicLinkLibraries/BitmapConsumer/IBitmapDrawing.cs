using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;

namespace BitmapConsumer
{
    public interface IBitmapDrawing
    {
        void Draw(Bitmap bmp);
    }
}
